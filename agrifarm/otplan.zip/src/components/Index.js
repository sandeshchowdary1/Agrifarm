import React from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import i18n from './i18n';
import './Index.css';

const Index = () => {
  const { t } = useTranslation();

  const handleLanguageChange = (e) => {
    i18n.changeLanguage(e.target.value);
    localStorage.setItem('language', e.target.value);
  };

  return (
    <div className='index-bg'>
      <div className="index-container">
        <div className="index-card">
          <h1 className="index-title">{t('welcome')}</h1>
          <p className="index-description">{t('description')}</p>

          <div className="language-select">
            <label htmlFor="language">{t('select_language')}:</label>
            <select id="language" onChange={handleLanguageChange} defaultValue={i18n.language}>
            <option value="te">తెలుగు</option>
              <option value="en">English</option>
              <option value="hi">हिंदी</option>
            </select>
          </div>

          <div className="button-group">
            <Link to="/signup" className="index-button signup-button">{t('signup')}</Link>
            <Link to="/login" className="index-button login-button">{t('login')}</Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Index;
