import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

const resources = {
  en: {
    translation: {
      welcome: "Welcome to AgriFarm",
      description: "A platform connecting farmers and labours for better agricultural practices.",
      select_language: "Select Language",
      signup: "Sign Up",
      login: "Login",
      name: "Name",
      gender: "Gender",
      select_gender:"select gender",
      male:"male",
      female:"female",
      other:"other",
      mobile: "Mobile Number",
      address: "Address",
      Send_otp:"Send otp",
      enter_otp:"enter otp",
      verify_otp: "Verify OTP",
      otp_verified:"OTP Verified!",
      register: "Register",
      Login_to_AgriFarm:"Login to AgriFarm",

      select_role: "Select Your Role",
      farmer: "Farmer",
      labour: "Laborer",
      proceed: "Proceed"
    }
  },
  hi: {
    translation: {
      welcome: "एग्रीफार्म में आपका स्वागत है",
      description: "एक ऐसा मंच जो किसानों और श्रमिकों को बेहतर कृषि प्रथाओं के लिए जोड़ता है।",
      select_language: "भाषा चुनें",
      signup: "साइन अप",
      login: "लॉग इन करें",
      name: "नाम",
      enter_name:"नाम",
      gender: "लिंग",
      select_gender:"लिंग चुनें",
      male:"पुरुष",
      female:"महिला",
      other:"अन्य",
      mobile: "मोबाइल नंबर",
      Enter_mobile_Number: "मोबाइल नंबर दर्ज करें ",
      address: "पता",
      enter_adress:"अपना पता दर्ज करें",
      Send_otp:"otp दर्ज करे",
      enter_otp:"enter otp",
      verify_otp: "ओटीपी सत्यापित करें",
      otp_verified:"ओटीपी सत्यापित",
      register: "रजिस्टर करें",
      Login_to_AgriFarm:"एग्रीफार्म पर लॉग इन करें",
      select_role: "अपनी भूमिका चुनें",
      farmer: "किसान",
      labour: "मजदूर",
      proceed: "आगे बढ़ें"
    }
  },
  te: {
    translation: {
      welcome: "అగ్రీఫార్మ్‌కు స్వాగతం",
      description: "రైతులను మరియు కార్మికులను మెరుగైన వ్యవసాయ పద్ధతులకు కలిపే వేదిక.",
      select_language: "భాషను ఎంచుకోండి",
      signup: "సైన్ అప్",
      login: "లాగిన్",
      name: "పేరు",
      enter_name:"పేరు నమోదు చేయండి",
      gender: "లింగం",
      select_gender:"లింగాన్ని ఎంచుకోండి",
      male:"పురుషుడు",
      female:"స్త్రీ",
      other:"ఇతర",
      mobile: "మొబైల్ నంబర్",
      Enter_mobile_Number: "మొబైల్ నంబర్‌ను నమోదు చేయండి",
      address: "చిరునామా",
      Send_otp:"otp పంపండి",
      enter_otp:"otp నమోదు చేయండి",
      enter_adress:"మీ చిరునామాను నమోదు చేయండి",    
      verify_otp: "OTP నిర్ధారించండి",
      otp_verified:"OTP ధృవీకరించబడింది",
      register: "నమోదు",
      Login_to_AgriFarm:"అగ్రిఫార్మ్‌కు లాగిన్ చేయండి",

      select_role: "మీ పాత్రను ఎంచుకోండి",
      farmer: "రైతు",
      labour: "కూలీ",
      proceed: "కొనసాగించండి"
    }
  }
};

i18n.use(initReactI18next).init({
  resources,
  lng: "te",
  fallbackLng: "te",
  interpolation: {
    escapeValue: false
  }
});

export default i18n;
